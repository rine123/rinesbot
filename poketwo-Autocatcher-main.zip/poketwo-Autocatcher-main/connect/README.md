a connection via url to check the current version and warn the user if using old Version.
✔️
