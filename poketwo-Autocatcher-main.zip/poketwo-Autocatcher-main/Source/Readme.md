Just Few Concept of Works. [Maybe Spoilers]
</br>
</br>
</br>
**I'm the type of person who loves to keep things private and only make things I care less about open-source.**
