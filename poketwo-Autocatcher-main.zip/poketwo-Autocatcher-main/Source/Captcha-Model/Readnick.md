### Captcha Solver

Based on Pytorch 
</br>
Yea,We are using Python for AI to solve Captchas.

--------
#### Progress

Current Accuracy:- 78% 

## These stats are for Google Re-captcha, Not Pokemon Recognization Stats
