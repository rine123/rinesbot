// Many stored.init are not shown in this github repo.
// WHICH?
const seeGIT = ("Many stored.init Things/files are not shown in this github repo.")
//=> Algorithms enabling for various task and plenty more.
// WHY?
// Privacy and no Guesses
const rem = require('rem.js');
const sut = require('suio.js');
const pror = require('pit-crp'.js)

//import the function from any of above (not gonna share coz its public)

console.log(rsp[0]);
console.log(rsp[5]);

dirwo.gui(' Poketwo Autocatcher ')
  .then(supUI => {
    return supUI
      .sort(poke,caught) // sort the total pokes and the caught pokes.
      .imp(60) // according to device to adjust
      .extend('poketwo-null.csv'); // save
  })
  .catch(err => { //in case of error
    console.error(err);
  });
