// This Converts init-stats into js format to Make it usable

const gitSEE = ('CODES WILL NOT BE SHARED HERE FOR THIS FILE!')

/*
Some imports
*/

/*
Codes.
*/

//notes(for me) - AUTO-remove // , convert into strings,variables and define exportable.
