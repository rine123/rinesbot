A convertor and temp storing for Logs.
secret.js for converting the file type and execute to make it look more beutiful rather than looking pretty sick.
[Premium Version]
