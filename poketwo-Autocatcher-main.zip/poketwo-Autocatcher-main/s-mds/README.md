Storage for md-assests to be Used.
