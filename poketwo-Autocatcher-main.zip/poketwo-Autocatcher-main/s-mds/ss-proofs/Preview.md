Seperate Folder for Containing its Proofs
