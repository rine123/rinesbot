<!--
  Title: Poketwo Autocatcher hack
  Description: This specific selfbot was designed to automatically catch Pokemon spawned on Discord by PokeCord bot. It also offers other utility functions to automate features like trading, releasing, ID search, etc. Apart from autocatching, the bot extends its features to more advanced version with better control.
  Author: Hope nexus
  Logo: https://i.imgur.com/85PNo2N.png
  Tags: discord-bot, discord, selfbot, poketwo-selfbot, poketwo, python,js, pokemon, poketwo-discord-bot, catch-pokemon, poketwo-hack,
        poketwo discord bot, poketwo discord bot, catch pokemon, poketwo hack, discord-bot, poketwo-bot, autocatcher, premium, auto-trade,
        donations, poketwo-catcher , accurate ,poketwo-autocatcher, poketwo-selfbot , Pokecord , pokecord , pokerealm , pokemon , bot , Market , Mass Trade , 
        Artificial intelligence , Auction , Official , server , Hope , Nexus , Working , Banerus , 100% , Latest , version , Mewbot , Reddit
-->

<meta name="description" content="This specific selfbot was designed to automatically catch Pokemon spawned on Discord by Poketwo bot. It also offers other utility functions to automate features like trading, releasing, ID search, etc. Apart from autocatching, the bot extends its features to more advanced version with better control."/>
<meta name="keywords" content="discord-bot, discord, selfbot, poketwo-selfbot, pokecord, python, pokemon, poketwo-discord-bot, catch-pokemon, poketwo-hack, discord bot, poketwo discord bot, catch pokemon, poketwo hack, discord-bot, poketwo-bot, autocatcher, premium, auto-trade, donations, pokecord-catcher, pokecord-autocatcher , free , poketwo-selfbot"/>

<meta name="author" content="Team-banerus"/>
<meta name="url" content="https://github.com/team-banerus/Poketwo-autocatcher" />
<meta name="og:title" content="Poketwo Autocatcher"/>
<meta name="google-site-verification" content="premium best" />
<meta name="og:url" content="https://github.com/team-banerus/Poketwo-autocatcher" />
<meta name="og:image" content="https://i.imgur.com/85PNo2N.png" />
<meta name="og:description" content="This specific selfbot was designed to automatically catch Pokemon spawned on Discord by Poketwo bot. It also offers other utility functions to automate features like trading, releasing, ID search, etc. Apart from autocatching, the bot extends its features to more advanced version with better control."/>

<img src="https://i.imgur.com/85PNo2N.png" align="left" height="160px"><h1>Pokétwo ∆ Autocatcher</h1>
</br>
~ By BANERUS
</br>
</br>
<!--
# comment
-->

<img src="https://poketwo.net/_next/image?url=%2Fassets%2Flogo.png&w=256&q=75" align="right" height="120px"><h1>ABOUT</h1>
This is the **The Most Light-Weighted Program/system To Autocatch Poketwo with Ease of handling & tons of Utilities and it Works on mostly Every Device.**

> **`Current Version:` 5.3.6**
### Official website:- will be released soon! am
---

<!--
Gif here
-->
  :sparkles: | This Bot works with the Current Poketwo(2021)!  `Poketwo Autocatcher` is just for a Perfect Title It is Beyond that with Auto-Leveler,Auto-Market,Auto-Release, Auto-setup and Plenty of Other Features.
:---: | :---

## Features
* <ins>The Bot has Several Utilities/Features , So I have listed Some Major Features/Utilities ignoring Complicated/Minor Stuff Below For Easy Lisiting :</ins>
  + Why we are Best to Choose 🥇 :-
      - Recognize Pokémons `(Alolan - Galarian - Gen 7 included).`
      - Automatically catch them all `(With a set delay/Random).`
      - Can deal with high amounts of Pokémon `[INTENSE]`
      - **Undetectable and applies different Algorithms + custom delays to fitness the behavior.`[leveler,autocatcher,auto-market]`**
      - An auto leveler will level your pokémon.
      - You can specify which pokémon to level up first`(list of pokeids).`
      - Spam multiple random messages using semicolons as `separator (1;2;3).`
      - Be notified when a pokémon is detected.
      - A Channel Logger to Logs Pokemon it has Caught
      - A DM logger to DM you when `Legendary/mythical/custom-pokes/shiny` are Caught
      - Be notified when a pokémon is spawned.
      - Auto-Buy Market `(Customizable Settings- like IVS/LVLS/NAME/CHECK-INTERVAL/more)`
      - DM you before Buying the Pokemon `(in case of offline-can set Wait Command)`
      - Mass-Pokemon Sell Market `(Customizable Settings- Price/lvl/args/IV/name/more)`
      - Mass-Release Pokemon `(Customizable Settings - ignore-pkms/lvl/iv/name/time/reminder/more)`
      - Auto-buy Items from Poketwo-shop `(ON/OFF + customizable items name/more)`
      - Cron Task`(scheduled actions)` can be easily adjusted/packed `(Customizable Settings :- [example- buy incense/shards/any/more] )` 
      - Whitelist/Blacklist The Server to Catch/Work
      - Generate Mass PokemonIDS of Specific Page`(via page- p!p)`
      - Mass Trade Pokemons Easily
      - Build-in Securities to Keep the Auto to Only respond to you/couple of people Allowed `(via - IDS in settings)`
      - Lesser Work Utilities such as - SERVER JOINER(via Invite) , `+say <cmnd>` to follow your command/text `(master-slave control)`
      - The Bot Works 24HOURS a Day.`(24/7)`
      - Use the program on multiple accounts.
      - Log error in a debug file `(in case of glitch).`
      - Easy setup `(no need to open any text file)`
      - The Auto-catcher can Restart itself,If it stops
      - Regularly maintained.
      - **Lifetime Support and FREE UPDATES**
 
__There are Plenty more customization and Features Available not included in this List__

<!--
![Works](https://media1.giphy.com/media/9cepV83q9ZVW8vAJ2w/giphy.gif)
![Works](https://media0.giphy.com/media/gIG0Aw7vFsU8fKKywD/giphy.gif)
![Works](https://cdn.discordapp.com/attachments/50f4587263242534913/780038260457209856/20201122_171216_edited.jpg)
![Works](https://cdn.discordapp.com/attachments/504587263242534913/780038815850823701/20201122_171514_edited.jpg)
![Works](https://media4.giphy.com/media/fMH1ennRztVJkjtvRr/giphy.gif)
old ss
-->

## Compatible Devices
| **🖥️ Computers :-** | **📱 Mobile/Phone/Tablets :-** |
| ------------- | ------------- |
| Windows | Android |
| Linux | IOS |
| Mac-OS |

## Perks
> **Perks are some extra Integrity given to You!**
- Documentations of settings and Other Worth stuff.
- Request New Features
- Source code `[Files of the Autocatcher/system/Program]`
- Support and Queries

# Discord Server
1. link:- [discord server](https: https://discord.gg/VKGamvbWQ2) `[Link will be Invalid - to solve :- Remove github.com/xyz/`and you will get `discord.gg/link` ]

# Tutorial/Trailer Video
soon.

# How to get it
1. Join Our discord server /  Start a discussion in the repo.
2. star this repo and Paypal/Google pay me. [Prices/More Details are On DISCORD serer]
3. If you want me to setup, feel free to send me a DM.

# Setting Up
1. There is a Documentation/Guide Given When you Purchase this Program to Adjust The Settings With Their Explanations.

# Disclaimer
1. I (and others contributors) are not responsible for any actions you perform using it. Use it at your own risk.
2. Selfbots violate Discord TOS and PokeTwo TOS and if you get caught using it, you will get banned (if that's the case I suggest you to switch/pause, but it rarely happens). Be careful about how you use the bot.
3. I would not recommend use this self-bot in public servers (especially Official PokeTwo Servers)
4. This Project Will be Continued Till Poketwo is Present and WE Will Never stop Updating this Autocatcher `(Lifetime)`
 
> The Intention to Create this Project was to give you a amplify Over Others and have the most Rare `Pokemons(shiny/legs/myth/ub/events)` and Wealth.(ignore Hoarding/Showing-off 100k+Pokes in Public `by p!profile` creating a Doubt)

# Terms & Conditions
1. You will receive the bot with the deployment instructions after the payment has been acknowledged.
2. Since Poketwo keeps updating , Stay patient until I patch the error for it.
3. All donations are non-refundable.
4. I (and others contributors) for this repo not responsible for any legal suits.

# Testimonials
a small png formatted gif.

